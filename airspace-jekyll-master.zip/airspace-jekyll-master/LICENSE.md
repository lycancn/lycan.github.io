Terms and Conditions for Free Templates - from https://www.themefisher.com/license
==================================================================================
1. You cannot remove the copyright link to Themefisher without buying the license.
2. You have the rights to use the templates for personal and commercial project(s).
3. You are allowed to make necessary modification(s) to our templates to fit your purpose.
4. Modification of the template or part it does not grant ownership of the template.
5. You cannot resell, redistribute, or sub-license any of Themefisher’s templates.
6. You can host Themefisher template to your website with full author credit
7. You are most welcome to share our templates with your clients/friends, but please share our license with them so that they can be aware of our copyrights.
8. You can convert our templates on any CMS (like WordPress, Joomla etc.) for your client and personal purposes but cannot resell these templates after the CMS conversion.

This jekyll port is not associated with ThemeFisher. All design credit to the original authors of this template.
